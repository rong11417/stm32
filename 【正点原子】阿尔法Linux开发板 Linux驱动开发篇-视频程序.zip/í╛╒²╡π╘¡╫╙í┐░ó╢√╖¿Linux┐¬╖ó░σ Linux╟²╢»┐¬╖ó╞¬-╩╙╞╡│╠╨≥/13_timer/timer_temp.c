#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/gpio.h>
#include <linux/of_gpio.h>

#define TIMER_CNT     1
#define TIMER_NAME    "timer"

/* timer设备结构体 */
struct timer_dev{
    dev_t devid;
    int major;
    int minor;
    struct cdev cdev;
    struct class *class;
    struct device *device;
    struct device_node *nd;
};

struct timer_dev timerdev; /* timerdev */

static int timer_open(struct inode *inode, struct file *filp)
{
    filp->private_data = &timerdev;
    return 0;
}

static int timer_release(struct inode *inode, struct file *filp)
{
    
    return 0;
}

static ssize_t timer_write(struct file *filp, const char __user *buf,
			 size_t count, loff_t *ppos)
{
    int ret = 0;


    return ret;
}

/* 操作集 */
static const struct file_operations timerdev_fops = {
    .owner		=	THIS_MODULE,
	.write		=	timer_write,
	.open		=	timer_open,
	.release	=	timer_release,
};

/* 驱动入口函数 */
static int __init timer_init(void)
{

    int ret = 0;

    /* 注册字符设备驱动 */
    timerdev.major = 0;
    if(timerdev.major) { /* 给定主设备号 */
        timerdev.devid = MKDEV(timerdev.major, 0);
        ret = register_chrdev_region(timerdev.devid, TIMER_CNT, TIMER_NAME);
    } else {            /* 没给定设备号 */
        ret = alloc_chrdev_region(&timerdev.devid, 0, TIMER_CNT, TIMER_NAME);
        timerdev.major = MAJOR(timerdev.devid);
        timerdev.minor = MINOR(timerdev.devid);
    }
    if(ret < 0) {
        goto fail_devid;
    }

    printk("timerdev major = %d, minor = %d\r\n", timerdev.major, timerdev.minor);

    /* 2,初始化cdev */
    timerdev.cdev.owner = THIS_MODULE;
    cdev_init(&timerdev.cdev, &timerdev_fops);

    /* 3,添加cdev */
    ret = cdev_add(&timerdev.cdev, timerdev.devid, TIMER_CNT);
    if (ret)
		goto fail_cdevadd;

    /* 4、创建类 */
    timerdev.class = class_create(THIS_MODULE, TIMER_NAME);
    if(IS_ERR(timerdev.class)) {
        ret = PTR_ERR(timerdev.class);
        goto fail_class;
    }

    /* 5,创建设备  */
    timerdev.device = device_create(timerdev.class, NULL, timerdev.devid, NULL, TIMER_NAME);
    if(IS_ERR(timerdev.device)) {
        ret = PTR_ERR(timerdev.device);
        goto fail_device;
    }



    return 0;

fail_device:
    class_destroy(timerdev.class);
fail_class:
    cdev_del(&timerdev.cdev);
fail_cdevadd:
    unregister_chrdev_region(timerdev.devid, TIMER_CNT);
fail_devid:
    return ret;

}

/* 驱动出口函数 */
static void __exit timer_exit(void)
{
    /* 注销字符设备驱动 */
    cdev_del(&timerdev.cdev);
    unregister_chrdev_region(timerdev.devid, TIMER_CNT);

    device_destroy(timerdev.class, timerdev.devid);
    class_destroy(timerdev.class);

}

module_init(timer_init);
module_exit(timer_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("zuozhongkai");
