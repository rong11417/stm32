#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/gpio.h>
#include <linux/of_gpio.h>
#include <linux/string.h>
#include <linux/irq.h>
#include <asm/mach/map.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/interrupt.h>
#include <linux/input.h>
#include <linux/i2c.h>
#include <linux/delay.h>

struct ft5x06_dev {

    void *private_data;
};

static struct ft5x06_dev ft5x06;

/* 读取FT5426的N个寄存器值 */
static int ft5x06_read_regs(struct ft5x06_dev *dev, u8 reg, void *val, int len)
{

    struct i2c_msg msg[2];
    struct i2c_client *client = (struct i2c_client*)dev->private_data;

    /*  msg[0]发送要读取的寄存器首地址 */
    msg[0].addr  = client->addr; /* 从机地址，也就是FT5X06地址 */
    msg[0].flags = 0;           /* 表示为要发送的数据 */
    msg[0].buf = &reg;          /* 要发送的数据，也就是寄存器地址 */
    msg[0].len = 1;             /* 要发送的寄存器地址长度为1 */

    /* msg[1]读取数据 */
    msg[1].addr  = client->addr; /* 从机地址，也就是FT5X06地址 */
    msg[1].flags = I2C_M_RD;     /* 表示读数据 */
    msg[1].buf = val;           /* 接收到的从机发送的数据 */
    msg[1].len = len;             /* 要读取的寄存器长度 */

	return i2c_transfer(client->adapter, msg, 2);
}

/* 向FT5X06写N个寄存器的数据 */
static int ft5x06_write_regs(struct ft5x06_dev *dev, u8 reg, u8 *buf, u8 len)
{
    u8 b[256];
    struct i2c_msg msg;
    struct i2c_client *client = (struct i2c_client*)dev->private_data;
    
    /* 构建要发送的数据，也就是寄存器首地址+实际的数据 */
    b[0] = reg;
    memcpy(&b[1], buf, len);

    msg.addr  = client->addr; /* 从机地址，也就是FT5X06地址 */
    msg.flags = 0;           /* 表示为要发送的数据 */
    msg.buf = b;            /* 要发送的数据，寄存器地址+实际数据 */
    msg.len = len + 1;       /* 要发送的数据长度：寄存器地址长度+实际的数据长度 */

	return i2c_transfer(client->adapter, &msg, 1);
}

/* 向FT5X06一个寄存器写数据 */
static void ft5x06_write_reg(struct ft5x06_dev *dev, u8 reg, u8 data)
{
    u8 buf  = 0;
    buf = data;
    ft5x06_write_regs(dev, reg, &buf, 1);
}

static int ft5x06_probe(struct i2c_client *client, 
                        const struct i2c_device_id *id)
{
    int ret  = 0;
    printk("ft5x06_probe!\r\n");

    return 0;
}

static int ft5x06_remove(struct i2c_client *client)
{
    return 0;
}

/* 传统的匹配表 */
static struct i2c_device_id ft5x06_id[] = {
    {"edt-ft5426", 0},
    {}
};

/* 设备树匹配表 */
static struct of_device_id ft5x06_of_match[] = {
    {.compatible = "edt,edt-ft5426",}, 
    {}
};

/* i2c_driver */
static struct i2c_driver ft5x06_driver = {
    .probe = ft5x06_probe,
    .remove = ft5x06_remove,
    .driver = {
        .name = "edt_ft5x06",
        .owner = THIS_MODULE,
        .of_match_table = of_match_ptr(ft5x06_of_match),
    },
    .id_table = ft5x06_id,
};

/* 驱动入口函数 */
static int __init ft5x06_init(void)
{

    int ret = 0;

    ret = i2c_add_driver(&ft5x06_driver);

    return ret;

}

/* 驱动出口函数 */
static void __exit ft5x06_exit(void)
{
    i2c_del_driver(&ft5x06_driver);
}

module_init(ft5x06_init);
module_exit(ft5x06_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("zuozhongkai");
